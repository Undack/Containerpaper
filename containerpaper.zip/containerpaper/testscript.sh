#!/bin/bash

# Warnings first
# DO NOT RUN THIS SCRIPT OVER THE INTERNET, PROTECTIONS HAVE BEEN DISABLED
# DO NOT RUN THIS SCRIPT MORE THAN ONCE A SECOND, IT WILL INTERFERE WITH DIRECTORY CREATION
# Since this probably won't be run that often ever, not going to implement better method
# RUN AS ROOT

#also don't trust the comments in this file, it was adapted from another script

# Script requires the following nonstandard packages
# Debian Host: rdumtool, SSHpass
# OpenWRT Clients: Stress-NG, SSH server

# All definitions go here baby

#foreign variables
IP="192.168.1.219"
port="22"
#port="2222"
#port="5555"
#port="3333"

#they werent
#login credentials, same hat as before, but it pays to be flexible
#username="user"
#password="debian"
username="pi"
password="raspberry"
#username="linuxserver"
#password="password"
#username="test"
#password="test"

#local variables
device="/dev/rfcomm0"

#capture duration and directory names
capture_duration=60 #seconds
directory=$(date +%Y%m%d_%H%M%S)

# Function to capture stress data
perform_foreign_capture() {
	local device_ip="$1"
	local username="$2"
	local password="$3"
	local capture_duration="$4"
	local path="./captures/$5"
    local port="$6"

	# Start tcpdump to capture packes, -W will stop it from splitting capture into multiple files
	# using 'single' quotes here causes command to be interpreted on server so we can use it's
	# HOSTNAME variable instead of ours
    

    #in case someone one day reads this
    #i have no idea why piping the output to a file makes this work on docker hosts
    #i was stuck for 2 days on this
    #i hate computing
    sshpass -p $password ssh -p $port -o StrictHostKeyChecking=no $username@$device_ip "stress-ng --matrix 0 -t $capture_duration --metrics --log-file stress.txt" > output.txt &
    echo "stress test started"

	sleep $capture_duration
	echo "$device_ip done"
    sleep 10 #just in case
    
	# Transfer the capture file to the host then delete from router
	sshpass -p $password scp -P $port -o StrictHostKeyChecking=no $username@$device_ip:stress.txt $path
	sshpass -p $password ssh -p $port -o StrictHostKeyChecking=no $username@$device_ip "rm -f stress.txt" 
}

# Function to capture power data
perform_local_capture() {
	local device="$1"
	local path="./captures/$2"
    local capture_duration="$3"

	# Start rdum to monitor power
    rdumtool --device-type=UM24C --serial-device=$device --clear-data-group
	sudo rdumtool --device-type=UM24C --serial-device=$device --json --watch 5 >> $path/power.json & 
	echo "local capture started"
	
	# and stop
	sleep $capture_duration
	killall rdumtool
	echo "local capture done"

}

#start of script proper

#root check
if [ "$(id -u)" -ne 0 ]; then echo "Please run as root." >&2; exit 1; fi

mkdir captures/$directory

# Start captures on both devices simultaneously
perform_foreign_capture $IP $username $password $capture_duration $directory $port &

# And on local device
perform_local_capture $device $directory $capture_duration & 

